Module example.com/empty is used to test that gorelease works
in a module with no packages.
