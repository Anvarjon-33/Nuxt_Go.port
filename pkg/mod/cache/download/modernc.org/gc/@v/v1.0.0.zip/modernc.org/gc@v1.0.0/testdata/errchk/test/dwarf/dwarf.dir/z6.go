
//line x6.go:4
package main
func F6() {}
