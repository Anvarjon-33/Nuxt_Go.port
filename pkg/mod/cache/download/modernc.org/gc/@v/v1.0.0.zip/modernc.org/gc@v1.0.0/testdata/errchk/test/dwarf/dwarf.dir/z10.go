


//line x10.go:4
package main
func F10() {}
