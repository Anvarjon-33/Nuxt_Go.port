# gc

Package GC is a Go compiler front end. (Work in progress)

Installation

    $ go get modernc.org/gc

Documentation: [godoc.org/modernc.org/gc](http://godoc.org/modernc.org/gc)
