package result

import (
	"errors"
)

var ErrTruncated = errors.New("truncated result")
