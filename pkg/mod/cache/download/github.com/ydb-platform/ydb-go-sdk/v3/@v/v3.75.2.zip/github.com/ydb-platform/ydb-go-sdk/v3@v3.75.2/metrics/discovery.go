package metrics

import (
	"github.com/ydb-platform/ydb-go-sdk/v3/trace"
)

func discovery(config Config) (t trace.Discovery) {
	return t
}
