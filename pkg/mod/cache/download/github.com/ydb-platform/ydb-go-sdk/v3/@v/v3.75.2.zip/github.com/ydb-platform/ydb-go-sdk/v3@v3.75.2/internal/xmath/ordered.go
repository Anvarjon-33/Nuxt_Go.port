//go:build go1.21
// +build go1.21

package xmath

import "cmp"

type ordered = cmp.Ordered
