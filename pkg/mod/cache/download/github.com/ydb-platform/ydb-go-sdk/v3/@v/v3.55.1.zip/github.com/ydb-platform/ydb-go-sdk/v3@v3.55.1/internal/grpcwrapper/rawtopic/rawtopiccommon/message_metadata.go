package rawtopiccommon

type MetadataItem struct {
	Key   string
	Value []byte
}
