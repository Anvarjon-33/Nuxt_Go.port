package metrics

import (
	"github.com/ydb-platform/ydb-go-sdk/v3/trace"
)

func scripting(config Config) (t trace.Scripting) {
	return t
}
