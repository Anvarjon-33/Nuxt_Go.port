//go:build tools

package ch

import (
	_ "github.com/dmarkham/enumer"
)
